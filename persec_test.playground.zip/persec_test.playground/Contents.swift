import Foundation


// ข้อที่ 1
func isValidBracketSequence(_ s: String) -> Bool {
    var stack: [Character] = []
    let matchingBrackets: [Character: Character] = [")": "(", "]": "[", "}": "{"]

    for char in s {
        if matchingBrackets.values.contains(char) {
            // Push opening bracket onto the stack
            stack.append(char)
        } else if let expectedOpen = matchingBrackets[char] {
            // Check if the top of the stack matches the expected opening bracket
            if stack.last == expectedOpen {
                stack.removeLast()
            } else {
                return false
            }
        }
    }

    // If the stack is empty, all brackets were matched
    return stack.isEmpty
}

// Test cases
print(isValidBracketSequence("()"))        // True
print(isValidBracketSequence("([]]"))      // False
print(isValidBracketSequence("([{}])"))    // True
print(isValidBracketSequence("([[{}]]]]")) // False
print(isValidBracketSequence(")"))         // False
print(isValidBracketSequence("(]}])"))     // False
print(isValidBracketSequence("([)]"))      // False
print(isValidBracketSequence("{"))         // False

// ******************************************** \\

// ข้อที่ 2
func sortStrings(_ input: [String]) -> [String] {
    return input.sorted { a, b in
        // Extract the numeric part from both strings
        let aNumber = Int(a.filter { $0.isNumber }) ?? Int.max
        let bNumber = Int(b.filter { $0.isNumber }) ?? Int.max

        // Extract the prefix (non-numeric part) from both strings
        let aPrefix = a.prefix { !$0.isNumber }
        let bPrefix = b.prefix { !$0.isNumber }

        // Compare by prefix first, then by number if prefixes are the same
        if aPrefix == bPrefix {
            return aNumber < bNumber
        } else {
            return aPrefix < bPrefix
        }
    }
}

// Test cases
print(sortStrings(["TH19", "SG20", "TH2"])) // ["SG20", "TH2", "TH19"]
print(sortStrings(["TH10", "TH3Netflix", "TH1", "TH7"])) // ["TH1", "TH3Netflix", "TH7", "TH10"]

// ******************************************** \\

// ข้อที่ 3
func autocomplete(search: String, items: [String], maxResult: Int) -> [String] {
    let searchLower = search.lowercased()
    
    // Filter items that contain the search term (case-insensitive)
    let filteredItems = items.filter { $0.lowercased().contains(searchLower) }
    
    // Sort items by the position of the search term, then alphabetically
    let sortedItems = filteredItems.sorted {
        let firstIndex = $0.lowercased().range(of: searchLower)?.lowerBound.utf16Offset(in: $0) ?? Int.max
        let secondIndex = $1.lowercased().range(of: searchLower)?.lowerBound.utf16Offset(in: $1) ?? Int.max
        return firstIndex < secondIndex
    }
    
    // Return up to `maxResult` items
    return Array(sortedItems.prefix(maxResult))
}

// Test cases
print(autocomplete(search: "th", items: ["Mother", "Think", "Worthy", "Apple", "Android"], maxResult: 2))  // Output: ["Think", "Mother"]

// ******************************************** \\

// ข้อที่ 4
// Function to convert an Int to Roman Numerals
func intToRoman(_ num: Int) -> String {
    let romanValues = [
        (1000, "M"), (900, "CM"), (500, "D"), (400, "CD"),
        (100, "C"), (90, "XC"), (50, "L"), (40, "XL"),
        (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")
    ]

    var number = num
    var result = ""

    for (value, symbol) in romanValues where number >= value {
        result += String(repeating: symbol, count: number / value)
        number %= value
    }

    return result
}

// Function to convert Roman Numerals to an Int
func romanToInt(_ roman: String) -> Int {
    let romanValues: [Character: Int] = ["I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000]

    var total = 0, previousValue = 0

    for char in roman.reversed() {
        let value = romanValues[char] ?? 0
        total += (value < previousValue) ? -value : value
        previousValue = value
    }

    return total
}

// Test cases
print(intToRoman(1989)) // "MCMLXXXIX"
print(intToRoman(2000)) // "MM"
print(intToRoman(68))   // "LXVIII"
print(intToRoman(109))  // "CIX"

print(romanToInt("MCMLXXXIX")) // 1989
print(romanToInt("MM"))        // 2000
print(romanToInt("LXVIII"))    // 68
print(romanToInt("CIX"))       // 109

// ******************************************** \\

// ข้อที่ 5
func sortDigitsDescending(_ num: Int) -> Int {
    let sortedString = String(num).sorted(by: >).map { String($0) }.joined()
    return Int(sortedString) ?? 0
}

// Test cases for sortDigitsDescending
print(sortDigitsDescending(3008)) // 8300
print(sortDigitsDescending(1989)) // 9981
print(sortDigitsDescending(2679)) // 9762
print(sortDigitsDescending(9163)) // 9631

// ******************************************** \\

// ข้อที่ 6
func generateTribonacci(_ start: [Int], _ count: Int) -> [Int] {
    guard count > start.count else {
        return Array(start.prefix(count))
    }

    var result = start
    while result.count < count {
        let nextValue = result.suffix(3).reduce(0, +)
        result.append(nextValue)
    }

    return result
}

// Test cases for Tribonacci sequence
print(generateTribonacci([1, 3, 5], 5)) // [1, 3, 5, 9, 17]
print(generateTribonacci([2, 2, 2], 3)) // [2, 2, 2]
print(generateTribonacci([10, 10, 10], 4)) // [10, 10, 10, 30]
print(generateTribonacci([], 5)) // [0, 0, 0, 0, 0]
print(generateTribonacci([3], 6)) // [3, 0, 0, 3, 3, 6]
